import React from 'react'

function UserItem({name}) {
    return (
        <div>
            <h2>My name is {name}</h2>
        </div>
    )
}

export default UserItem
 