import React, { useState } from 'react'

function ToggleText () {
    const [isTextShown, setIsTextShown] = useState(false)
    return (
        <>
            {isTextShown === true ? <p>Text</p> : ''}
            <button>Show text</button>
        </>
    )
}

export default ToggleText