import React from 'react'

import UserItem from "./shared/UserItem.jsx"
import PhotoItem from "./shared/PhotoItem.jsx"
import ToggleText from './shared/ToggleText.jsx'

function Content() {
    const data = {
        name: 'Valentin',
        age: 23,
        photo: 'https://avatars.githubusercontent.com/u/114210745?v=4'
    }
    return (
        <main>
            <div className="container">
                <UserItem name={data.name} />
                <h2>I'm {data.age}</h2>
                <PhotoItem photo_url = {data.photo}/>
                <ToggleText />
            </div>
        </main>
    )
}

export default Content
